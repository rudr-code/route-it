"""Solver package tests."""
